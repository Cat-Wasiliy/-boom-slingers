document.getElementById("root").innerHTML = `
  <h1 style="text-align:center;margin-top:40px;">🚀 Boom Slingers Prototype</h1>
  <p style="text-align:center;">Готовый шаблон для GitHub Pages.<br>Можешь заменить этот код на React-версию.</p>
`;